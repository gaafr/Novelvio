# Novelvio

Global rewards app scaffold.

- 17 languages
- 1000 points = $1
- Minimum withdrawal = $1
- Withdrawal methods: PayPal and USDT
- Supabase backend schema included

Important: real-money payouts require verified payment providers, server-side validation, fraud prevention, and compliance review.
