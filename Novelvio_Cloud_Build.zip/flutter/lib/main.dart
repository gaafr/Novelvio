import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

void main() => runApp(const NovelvioApp());

class NovelvioApp extends StatelessWidget {
  const NovelvioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Novelvio',
      debugShowCheckedModeBanner: false,
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('ar'), Locale('en'), Locale('de'), Locale('fr'),
        Locale('es'), Locale('it'), Locale('tr'), Locale('ru'),
        Locale('pt'), Locale('hi'), Locale('id'), Locale('zh'),
        Locale('ja'), Locale('ko'), Locale('nl'), Locale('pl'),
        Locale('uk'),
      ],
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Novelvio')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Earn rewards', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          const Text('Watch ads, complete tasks, invite friends and shop through offers.'),
          const SizedBox(height: 24),
          Card(child: ListTile(title: const Text('Balance'), subtitle: const Text('0 points = \$0.00'))),
          Card(child: ListTile(title: const Text('Minimum withdrawal'), subtitle: const Text('\$1.00'))),
          Card(child: ListTile(title: const Text('Withdrawal methods'), subtitle: const Text('PayPal • USDT'))),
        ],
      ),
    );
  }
}
