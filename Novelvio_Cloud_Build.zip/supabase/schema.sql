create table if not exists public.app_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb
);

insert into public.app_settings(key,value) values
('economy','{"points_per_usd":1000,"minimum_withdrawal_usd":1}')
on conflict (key) do nothing;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  referral_code text unique,
  created_at timestamptz default now()
);

create table if not exists public.wallets (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  points bigint not null default 0,
  updated_at timestamptz default now()
);

create table if not exists public.transactions (
  id bigint generated always as identity primary key,
  user_id uuid references public.profiles(id) on delete cascade,
  points bigint not null,
  type text not null,
  description text,
  created_at timestamptz default now()
);

create table if not exists public.withdrawals (
  id bigint generated always as identity primary key,
  user_id uuid references public.profiles(id) on delete cascade,
  amount_usd numeric(12,2) not null,
  method text not null,
  destination text not null,
  status text not null default 'pending',
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.wallets enable row level security;
alter table public.transactions enable row level security;
alter table public.withdrawals enable row level security;

create policy if not exists "profiles own read" on public.profiles
for select using (auth.uid() = id);

create policy if not exists "wallet own read" on public.wallets
for select using (auth.uid() = user_id);

create policy if not exists "transactions own read" on public.transactions
for select using (auth.uid() = user_id);

create policy if not exists "withdrawals own read" on public.withdrawals
for select using (auth.uid() = user_id);
