# Launch checklist

1. Create/configure the Supabase project.
2. Run `supabase/schema.sql`.
3. Put only the Supabase publishable key in the client app.
4. Never put a service_role/secret key in the app or GitHub.
5. Connect real ad/task/affiliate providers.
6. Implement server-side payout processing and fraud checks.
7. Configure PayPal/USDT providers according to supported countries.
8. Test withdrawals with a small controlled group before public launch.
